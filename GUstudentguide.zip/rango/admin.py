from django.contrib import admin
from rango.models import UserProfile

admin.site.register(UserProfile)
